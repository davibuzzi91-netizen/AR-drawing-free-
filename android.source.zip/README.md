# AR Drawing

Aplicativo Android (Kotlin + Jetpack Compose) para auxiliar o desenho físico.
O usuário escolhe uma imagem da galeria, ajusta tamanho e posição com dois dedos,
controla a transparência e usa a referência para desenhar no sketchbook.

## Estrutura

- `ProjectStore.kt`: persistência dos projetos (índice JSON + imagem em `filesDir`) e máscara de traços.
- `GlassComponents.kt`: botões e slider com aparência Liquid Glass.
- `MainActivity.kt`: telas Início, Ajuste e Trabalho.
