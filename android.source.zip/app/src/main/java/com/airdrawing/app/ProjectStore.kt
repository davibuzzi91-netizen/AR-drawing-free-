package com.airdrawing.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Maior lado guardado para a imagem de referência. Limita memória em fotos grandes. */
const val MAX_SOURCE_SIDE = 2048

/** Pixels com luminância abaixo deste valor são considerados traços escuros. */
const val LINE_LUMA_THRESHOLD = 175f

/** Abaixo deste valor o traço é totalmente opaco; entre os dois, a opacidade é gradual. */
const val LINE_SOLID_LUMA = 110f

/** Opacidade dos traços com 100% de transparência. Sobe até 1 conforme a transparência diminui. */
const val LINE_MIN_ALPHA = 0.25f

/**
 * Estado salvo de um projeto.
 * transparency vai de 0 (imagem opaca) a 1 (invisível); a opacidade aplicada é 1 - transparency.
 */
data class Project(
    val id: String,
    val transparency: Float = 0.5f,
    val scale: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val updatedAt: Long = System.currentTimeMillis()
)

class ProjectStore(private val context: Context) {

    private val root = File(context.filesDir, "projects").apply { mkdirs() }
    private val indexFile = File(root, "index.json")

    /** Todos os projetos, do mais recente para o mais antigo. */
    fun list(): List<Project> {
        if (!indexFile.exists()) return emptyList()
        val array = JSONArray(indexFile.readText())
        return (0 until array.length())
            .map { array.getJSONObject(it).toProject() }
            .sortedByDescending { it.updatedAt }
    }

    fun get(id: String): Project? = list().firstOrNull { it.id == id }

    /** Copia a imagem escolhida para o armazenamento interno e cria o projeto. */
    fun create(uri: Uri): Project {
        val id = UUID.randomUUID().toString()
        File(root, id).mkdirs()

        val decoded = decodeFromUri(uri, MAX_SOURCE_SIDE)
            ?: throw IllegalStateException("Não foi possível abrir a imagem")
        val flattened = flattenOnWhite(decoded)
        imageFile(id).outputStream().use { flattened.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        decoded.recycle()
        flattened.recycle()

        val project = Project(id = id)
        upsert(project)
        return project
    }

    fun save(project: Project) = upsert(project.copy(updatedAt = System.currentTimeMillis()))

    /** Decodifica a imagem do projeto reduzida para caber em maxSide. */
    fun decodeFile(id: String, maxSide: Int): Bitmap? {
        val file = imageFile(id)
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        val sample = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxSide)
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    fun imageFile(id: String): File = File(File(root, id), "source.jpg")

    private fun upsert(project: Project) {
        val all = list().filter { it.id != project.id } + project
        val array = JSONArray()
        all.forEach { array.put(it.toJson()) }
        indexFile.writeText(array.toString())
    }

    private fun decodeFromUri(uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxSide)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }
}

private fun sampleSizeFor(width: Int, height: Int, maxSide: Int): Int {
    var sample = 1
    while (width / (sample * 2) >= maxSide || height / (sample * 2) >= maxSide) sample *= 2
    return sample
}

/** Preenche o fundo com branco, para que PNGs transparentes não virem preto no JPEG. */
private fun flattenOnWhite(source: Bitmap): Bitmap {
    val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    Canvas(out).apply {
        drawColor(android.graphics.Color.WHITE)
        drawBitmap(source, 0f, 0f, null)
    }
    return out
}

/**
 * Cria uma máscara que contém somente os traços escuros da imagem, com a mesma alpha original.
 * Ela é desenhada por cima da referência para que as linhas não sumam quando a transparência aumenta.
 */
fun buildLineMask(source: Bitmap): Bitmap {
    val w = source.width
    val h = source.height
    val pixels = IntArray(w * h)
    source.getPixels(pixels, 0, w, 0, 0, w, h)

    for (i in pixels.indices) {
        val p = pixels[i]
        val a = (p ushr 24) and 0xFF
        if (a == 0) {
            pixels[i] = 0
            continue
        }
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        val luma = 0.299f * r + 0.587f * g + 0.114f * b
        pixels[i] = if (luma < LINE_LUMA_THRESHOLD) {
            val strength = ((LINE_LUMA_THRESHOLD - luma) / (LINE_LUMA_THRESHOLD - LINE_SOLID_LUMA)).coerceAtMost(1f)
            ((a * strength).toInt() shl 24)
        } else 0
    }
    return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
}

private fun Project.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("transparency", transparency.toDouble())
    .put("scale", scale.toDouble())
    .put("offsetX", offsetX.toDouble())
    .put("offsetY", offsetY.toDouble())
    .put("updatedAt", updatedAt)

private fun JSONObject.toProject(): Project = Project(
    id = getString("id"),
    transparency = getDouble("transparency").toFloat(),
    scale = getDouble("scale").toFloat(),
    offsetX = getDouble("offsetX").toFloat(),
    offsetY = getDouble("offsetY").toFloat(),
    updatedAt = getLong("updatedAt")
)
