package com.airdrawing.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min
import kotlin.math.roundToInt

/** Lado maior usado nos cartões da tela inicial. */
private const val CARD_PREVIEW_SIDE = 512

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AirDrawingApp() }
    }
}

sealed class Screen {
    data object Home : Screen()
    data class Adjust(val id: String) : Screen()
    data class Work(val id: String) : Screen()
}

/** Imagem de referência e sua máscara de traços, prontas para desenhar. */
class ReferenceAssets(
    val image: ImageBitmap,
    val lines: ImageBitmap,
    val width: Int,
    val height: Int
)

suspend fun loadAssets(store: ProjectStore, id: String): ReferenceAssets? = withContext(Dispatchers.Default) {
    val bitmap: Bitmap = store.decodeFile(id, MAX_SOURCE_SIDE) ?: return@withContext null
    val mask = buildLineMask(bitmap)
    ReferenceAssets(
        image = bitmap.asImageBitmap(),
        lines = mask.asImageBitmap(),
        width = bitmap.width,
        height = bitmap.height
    )
}

@Composable
fun AirDrawingApp() {
    val context = LocalContext.current
    val store = remember { ProjectStore(context) }
    val scope = rememberCoroutineScope()

    var stack by remember { mutableStateOf<List<Screen>>(listOf(Screen.Home)) }
    val current = stack.last()
    val projects = remember(stack) { store.list() }

    fun push(screen: Screen) {
        stack = stack + screen
    }

    fun pop() {
        if (stack.size > 1) stack = stack.dropLast(1)
    }

    BackHandler(enabled = stack.size > 1) { pop() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val project = withContext(Dispatchers.IO) { store.create(uri) }
                push(Screen.Adjust(project.id))
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        when (current) {
            Screen.Home -> HomeScreen(
                projects = projects,
                store = store,
                onPick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                // Projeto salvo abre direto na tela de AR Tracing.
                onOpen = { push(Screen.Work(it.id)) }
            )

            is Screen.Adjust -> AdjustScreen(
                store = store,
                id = current.id,
                onBack = { pop() },
                onStart = { push(Screen.Work(current.id)) }
            )

            is Screen.Work -> WorkScreen(
                store = store,
                id = current.id,
                onBack = { pop() },
                onClose = { stack = listOf(Screen.Home) }
            )
        }
    }
}

@Composable
fun HomeScreen(
    projects: List<Project>,
    store: ProjectStore,
    onPick: () -> Unit,
    onOpen: (Project) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Text("AR Drawing", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(20.dp))

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            GlassBox(
                Modifier.size(88.dp).clickable(onClick = onPick),
                shape = CircleShape
            ) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = "Pick a Image",
                    tint = Ink,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text("Pick a Image", fontSize = 14.sp, color = Muted)
        }

        Spacer(Modifier.height(24.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(projects, key = { it.id }) { project ->
                ProjectCard(project, store) { onOpen(project) }
            }
        }
    }
}

@Composable
fun ProjectCard(project: Project, store: ProjectStore, onClick: () -> Unit) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, project.id) {
        value = withContext(Dispatchers.IO) {
            store.decodeFile(project.id, CARD_PREVIEW_SIDE)?.asImageBitmap()
        }
    }
    val loaded = bitmap

    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(3f / 4f)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFFF2F2F7))
            .clickable(onClick = onClick)
    ) {
        if (loaded != null) {
            Image(
                bitmap = loaded,
                contentDescription = "Projeto salvo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun AdjustScreen(
    store: ProjectStore,
    id: String,
    onBack: () -> Unit,
    onStart: () -> Unit
) {
    val assets by produceState<ReferenceAssets?>(null, id) { value = loadAssets(store, id) }
    val saved = remember(id) { store.get(id) ?: Project(id) }
    var scale by remember(id) { mutableFloatStateOf(saved.scale) }
    var offset by remember(id) { mutableStateOf(Offset(saved.offsetX, saved.offsetY)) }
    val loaded = assets

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .pointerInput(id) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.2f, 8f)
                    offset += pan
                }
            }
    ) {
        if (loaded != null) {
            ReferenceCanvas(loaded, scale, offset, saved.transparency, Modifier.fillMaxSize())
        }

        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIcon(Icons.Filled.ArrowBack, "Voltar", onBack)
            GlassPill(
                text = "Start",
                onClick = {
                    store.save(saved.copy(scale = scale, offsetX = offset.x, offsetY = offset.y))
                    onStart()
                }
            )
        }
    }
}

/**
 * Tela de AR Tracing: câmera traseira ao vivo com a referência sobreposta.
 * A permissão de câmera é pedida ao entrar, se ainda não foi concedida.
 */
@Composable
fun WorkScreen(
    store: ProjectStore,
    id: String,
    onBack: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val assets by produceState<ReferenceAssets?>(null, id) { value = loadAssets(store, id) }
    val saved = remember(id) { store.get(id) ?: Project(id) }
    var transparency by remember(id) { mutableFloatStateOf(saved.transparency) }
    var scale by remember(id) { mutableFloatStateOf(saved.scale) }
    var offset by remember(id) { mutableStateOf(Offset(saved.offsetX, saved.offsetY)) }
    val loaded = assets

    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    LaunchedEffect(Unit) {
        if (!granted) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (granted) Color.Black else Color.White)
            .pointerInput(id) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.2f, 8f)
                    offset += pan
                }
            }
    ) {
        if (granted) {
            CameraPreview(Modifier.fillMaxSize())
            if (loaded != null) {
                ReferenceCanvas(
                    assets = loaded,
                    scale = scale,
                    offset = offset,
                    transparency = transparency,
                    modifier = Modifier.fillMaxSize(),
                    opaqueBackground = false
                )
            }
        } else {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    "O AR Drawing precisa da câmera para mostrar a referência sobre o papel.",
                    color = Ink,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
                GlassPill(
                    text = "Permitir câmera",
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIcon(Icons.Filled.ArrowBack, "Voltar", onBack)
            StretchyCloseButton(onClose)
        }

        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp)
                .align(Alignment.BottomCenter),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GlassBox(Modifier.weight(1f), shape = RoundedCornerShape(28.dp)) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 14.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Transparência", fontSize = 13.sp, color = Muted)
                        Text("${(transparency * 100).roundToInt()}%", fontSize = 13.sp, color = Muted)
                    }
                    Spacer(Modifier.height(8.dp))
                    GlassSlider(value = transparency, onValueChange = { transparency = it })
                }
            }

            GlassBox(
                Modifier
                    .size(64.dp)
                    .clickable {
                        store.save(
                            saved.copy(
                                transparency = transparency,
                                scale = scale,
                                offsetX = offset.x,
                                offsetY = offset.y
                            )
                        )
                        Toast.makeText(context, "Projeto salvo", Toast.LENGTH_SHORT).show()
                    },
                shape = CircleShape
            ) {
                DiskIcon()
            }
        }
    }
}

/** Transmissão ao vivo da câmera traseira (CameraX). Libera a câmera ao sair da tela. */
@Composable
fun CameraPreview(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val owner = context as ComponentActivity
    var provider by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    DisposableEffect(Unit) {
        onDispose { provider?.unbindAll() }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val view = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            val future = ProcessCameraProvider.getInstance(ctx)
            future.addListener({
                val cameraProvider = future.get()
                provider = cameraProvider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            }, ContextCompat.getMainExecutor(ctx))
            view
        }
    )
}

/** Dois discos sobrepostos, para o botão de salvar. */
@Composable
fun DiskIcon() {
    Canvas(Modifier.size(28.dp)) {
        val radius = size.minDimension * 0.34f
        val stroke = Stroke(width = 2.dp.toPx())
        drawCircle(
            color = Ink,
            radius = radius,
            center = Offset(size.width * 0.40f, size.height * 0.42f),
            style = stroke
        )
        drawCircle(
            color = Ink,
            radius = radius,
            center = Offset(size.width * 0.60f, size.height * 0.58f),
            style = stroke
        )
    }
}

/**
 * Desenha a referência com a transparência escolhida.
 * A imagem usa a opacidade atual; os traços escuros são desenhados por cima com
 * opacidade mínima, então continuam legíveis mesmo com transparência alta.
 * Com opaqueBackground = false, o fundo fica livre para a câmera aparecer por baixo.
 */
@Composable
fun ReferenceCanvas(
    assets: ReferenceAssets,
    scale: Float,
    offset: Offset,
    transparency: Float,
    modifier: Modifier = Modifier,
    opaqueBackground: Boolean = true
) {
    val opacity = 1f - transparency.coerceIn(0f, 1f)
    val lineAlpha = LINE_MIN_ALPHA + (1f - LINE_MIN_ALPHA) * opacity

    Canvas(modifier) {
        if (opaqueBackground) drawRect(Color.White)

        val base = min(size.width / assets.width, size.height / assets.height)
        val w = assets.width * base * scale
        val h = assets.height * base * scale
        val dstOffset = IntOffset(
            ((size.width - w) / 2f + offset.x).roundToInt(),
            ((size.height - h) / 2f + offset.y).roundToInt()
        )
        val dstSize = IntSize(w.roundToInt().coerceAtLeast(1), h.roundToInt().coerceAtLeast(1))

        drawImage(assets.image, dstOffset = dstOffset, dstSize = dstSize, alpha = opacity)
        drawImage(assets.lines, dstOffset = dstOffset, dstSize = dstSize, alpha = lineAlpha)
    }
}
