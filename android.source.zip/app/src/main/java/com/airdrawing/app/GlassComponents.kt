package com.airdrawing.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF1C1C1E)
val Muted = Color(0xFF8E8E93)
val GlassTop = Color(0xCCFFFFFF)
val GlassBottom = Color(0x80E5E5EA)
val GlassRim = Color(0x40808090)

private val ThumbWidth = 56.dp

/** Superfície de vidro: gradiente translúcido com borda clara. */
@Composable
fun GlassBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(50),
    top: Color = GlassTop,
    bottom: Color = GlassBottom,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(1.dp, GlassRim, shape),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun GlassPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    GlassBox(
        modifier
            .clickable(onClick = onClick)
            .height(52.dp)
            .padding(horizontal = 28.dp),
        shape = RoundedCornerShape(26.dp)
    ) {
        Text(text, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassIcon(icon: ImageVector, description: String, onClick: () -> Unit) {
    GlassBox(Modifier.size(48.dp).clickable(onClick = onClick), shape = CircleShape) {
        Icon(icon, contentDescription = description, tint = Ink)
    }
}

/**
 * Botão X: fica vermelho enquanto é pressionado ou segurado e estica ao ser tocado.
 * Não pede confirmação.
 */
@Composable
fun StretchyCloseButton(onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val top by animateColorAsState(if (pressed) Color(0xF5FF5A5F) else GlassTop, label = "closeTop")
    val bottom by animateColorAsState(if (pressed) Color(0xE0E5484D) else GlassBottom, label = "closeBottom")
    val stretchX by animateFloatAsState(if (pressed) 1.22f else 1f, label = "stretchX")
    val stretchY by animateFloatAsState(if (pressed) 0.82f else 1f, label = "stretchY")

    GlassBox(
        Modifier
            .size(48.dp)
            .graphicsLayer {
                scaleX = stretchX
                scaleY = stretchY
            }
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        shape = CircleShape,
        top = top,
        bottom = bottom
    ) {
        Icon(
            Icons.Filled.Close,
            contentDescription = "Encerrar",
            tint = if (pressed) Color.White else Ink
        )
    }
}

/**
 * Slider de transparência 0 a 1.
 * Em repouso o cursor é branco e achatado. Ao tocar, vira vidro translúcido e a barra azul
 * fica visível por baixo dele.
 */
@Composable
fun GlassSlider(value: Float, onValueChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    var dragging by remember { mutableStateOf(false) }
    var widthPx by remember { mutableFloatStateOf(1f) }

    val thumbHeight by animateDpAsState(if (dragging) 30.dp else 14.dp, label = "thumbHeight")
    val thumbTop by animateColorAsState(if (dragging) Color(0x40FFFFFF) else Color.White, label = "thumbTop")
    val thumbBottom by animateColorAsState(if (dragging) Color(0x14FFFFFF) else Color.White, label = "thumbBottom")
    val thumbShape = RoundedCornerShape(50)

    Box(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            // Um único gesto cobre toque e arraste: o cursor fica de vidro enquanto o dedo
            // estiver na tela, em qualquer ponto da área do slider.
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    dragging = true
                    onValueChange((down.position.x / widthPx).coerceIn(0f, 1f))
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (change.pressed) {
                            onValueChange((change.position.x / widthPx).coerceIn(0f, 1f))
                            change.consume()
                        }
                    } while (change.pressed)
                    dragging = false
                }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        // Trilho de fundo
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0x337A7AFF))
        )
        // Progresso azul
        Box(
            Modifier
                .fillMaxWidth(value.coerceIn(0.001f, 1f))
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF0A84FF))
        )
        // Cursor
        BoxWithConstraints(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = (maxWidth - ThumbWidth) * value.coerceIn(0f, 1f))
                    .width(ThumbWidth)
                    .height(thumbHeight)
                    .clip(thumbShape)
                    .background(Brush.verticalGradient(listOf(thumbTop, thumbBottom)))
                    .border(1.dp, Color(0xD9FFFFFF), thumbShape)
            )
        }
    }
}
